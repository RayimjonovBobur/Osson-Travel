export const DetaileDate = [
  { headerTitle: "TAVSIF" },
  { headerTitle: "DASTUR" },
  { headerTitle: "DAM OLISH MASKANI HAQIDA" },
  { headerTitle: "NARXLAR" },
  { headerTitle: "FOTO" },
];
